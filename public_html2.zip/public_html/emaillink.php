<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>please verify your email Address</title>
</head>
<body style='background-color:#f6f6f6'>
    <div style='margin:0 auto; width:35%; height:50vh;background-color:white; margin-top:10vh'>
        <div style='text-align:center; padding:3vh; width:100%; background-color:#0058ab; color:white; box-sizing:border-box; font-size:25px;font-family: Arial, Helvetica, sans-serif;border-bottom:2px solid gray;
'>
         <b>NEWTNBOOKSONLINE</b>
        </div>
        <div  style='text-align:center;font-family: Arial, Helvetica, sans-serif;'>
        <br>
            <h1>Please verify Your email address</h1>
            <br>
            <p style='font-size:23px; width:50%;font-size:17px;margin:0 auto;'>We need to verify your email address before activating your  account.</p>
            <a href='http://localhost/projects/Newtonbooks/public_html/verify?token={$token}'><button style='margin-top:8vh; width:30%; height:50px; line-height:20px; color:white;background-color:#0058ab; border:none;border-radius:5px;cursor:pointer;'>Verify</button></a>
        </div>
    </div>
</body>
</html>