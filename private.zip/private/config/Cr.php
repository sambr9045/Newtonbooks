<?php
    // defining database credentiale

    define("HOSTNAME", "localhost");
    define("HOSTUSERNAME", "root");
    define("HOSTPASSWORD", "");
    define("DBNAME", "newtonbooks");

    define("STMT_USERNAME", "no-reply@shamsbase.com");
    define("STMT_PASSWORD", "shamsbase@90454544");
    define("stmt_host", "smtp.hostinger.com");
    define("stmt_port", "587");

    define("apiKey", "PQ8WbSIVf1EvfQkE");
    define("ApiSecret", "2D8LLcVIF50WkYshoa3JiZ4nZlP0pSRV");
    define("secretToken", "e743f5a216d1685dca6bec604a7c602e83aec92613486f0c9be345af8f844e05");

    $admin_login_username = ['theissacnewton', 'boukari'];
    $admin_login_password = ['theissacnewton', '90454544'];



?>