<?php

// initialize all files together

// Loading crendetials file
include_once('config/Cr.php');
include_once('classes/db.query.inc');
include_once('classes/main.class.inc');
include_once('classes/functions.php');
include_once('fontEnd.php');

// Loading  db query class


// Loading main classe file







 
?>