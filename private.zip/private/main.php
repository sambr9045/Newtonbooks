<?php
    //  session_start();

     $db = new main_db(HOSTNAME, HOSTUSERNAME, HOSTPASSWORD, DBNAME);

    // // Admin section 

    
    
?>